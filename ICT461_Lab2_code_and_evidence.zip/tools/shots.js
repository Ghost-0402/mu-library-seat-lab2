const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
  const p = await b.newPage({ viewport: { width: 1000, height: 1000 } });
  await p.goto('file:///home/claude/lab2/evidence/lighthouse.report.html');
  await p.waitForTimeout(1500);
  await p.screenshot({ path: '../evidence/shot_lighthouse.png', clip: { x: 0, y: 0, width: 1000, height: 640 } });
  // expand passed audits section to show
  const j = JSON.parse(fs.readFileSync('../evidence/lighthouse.report.json'));
  const ax = JSON.parse(fs.readFileSync('../evidence/axe_results.json'));
  const rows = ax.results.map(r => `<tr><td>${r.label}</td><td class="n">${r.violations.length}</td><td class="n">${r.passes}</td><td class="n">${r.incomplete.length}</td><td class="n">${r.inapplicable}</td></tr>`).join('');
  const html = `<html><body style="font-family:Arial;margin:0;padding:24px;background:#fff;width:900px">
  <h2 style="margin:0 0 4px">axe-core ${ax.axeVersion} audit summary</h2>
  <p style="margin:0 0 14px;color:#333">Rule sets: WCAG 2.0 A/AA, WCAG 2.1 A/AA, WCAG 2.2 AA, best practices. Page: checkin.html (Chromium, headless).</p>
  <table style="border-collapse:collapse;width:100%;font-size:15px"><thead><tr style="background:#0d1f3c;color:#fff"><th style="text-align:left;padding:8px">Page state tested</th><th style="padding:8px">Violations</th><th style="padding:8px">Rules passed</th><th style="padding:8px">Needs review</th><th style="padding:8px">Not applicable</th></tr></thead><tbody>${rows}</tbody></table>
  <style>td{border:1px solid #888;padding:8px}td.n{text-align:center;font-weight:700}</style>
  <p style="margin:14px 0 0;font-weight:700;color:#14532d">Total WCAG violations across all states: ${ax.results.reduce((a,r)=>a+r.violations.length,0)}</p></body></html>`;
  await p.setContent(html);
  await p.screenshot({ path: '../evidence/shot_axe.png', clip: { x: 0, y: 0, width: 950, height: await p.evaluate(()=>document.body.scrollHeight) } });
  await b.close();
})();
