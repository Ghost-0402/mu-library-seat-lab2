const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs');
const axeSrc = fs.readFileSync('node_modules/axe-core/axe.min.js', 'utf8');
const axeVersion = require('axe-core/package.json').version;
const URL = 'http://localhost:8765/checkin.html';
const OUT = '../evidence/';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 } });
  const page = await ctx.newPage();
  await page.goto(URL);
  const tags = ['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa','best-practice'];
  async function runAxe(label) {
    await page.evaluate(axeSrc);
    const r = await page.evaluate(async (tags) => await axe.run(document, { runOnly: { type: 'tag', values: tags } }), tags);
    return { label, violations: r.violations.map(v => ({ id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.length })), passes: r.passes.length, incomplete: r.incomplete.map(v=>({id:v.id,nodes:v.nodes.length})), inapplicable: r.inapplicable.length, rules: r.passes.length + r.violations.length + r.incomplete.length + r.inapplicable.length };
  }
  const results = [];
  results.push(await runAxe('Initial page'));
  // screenshots: initial
  await page.screenshot({ path: OUT + 'shot_initial.png', fullPage: true });
  // error state
  await page.click('button[type=submit]');
  await page.waitForTimeout(300);
  results.push(await runAxe('After failed submit (all error messages shown)'));
  await page.screenshot({ path: OUT + 'shot_errors.png', fullPage: true });
  fs.writeFileSync(OUT + 'summary_text_errors.txt', await page.evaluate(() => document.getElementById('error-summary').innerText) + '\nlive: ' + await page.evaluate(()=>document.getElementById('form-status').textContent));
  // attribute snapshot for report
  const attrs = await page.evaluate(() => {
    const g = id => { const e = document.getElementById(id); return { aria_invalid: e.getAttribute('aria-invalid'), aria_describedby: e.getAttribute('aria-describedby'), err: document.getElementById(id + '-error').textContent }; };
    return { 'student-id': g('student-id'), 'full-name': g('full-name') };
  });
  fs.writeFileSync(OUT + 'attrs_error.json', JSON.stringify(attrs, null, 2));
  // real-time validation demo: partial id
  await page.reload();
  await page.fill('#student-id', '2023');
  await page.press('#student-id', 'Tab');
  await page.waitForTimeout(200);
  await page.screenshot({ path: OUT + 'shot_realtime.png', clip: { x: 0, y: 150, width: 1100, height: 330 } });
  await page.fill('#student-id', '202302571');
  const fixed = await page.evaluate(() => document.getElementById('student-id').getAttribute('aria-invalid'));
  fs.writeFileSync(OUT + 'attrs_fixed.txt', 'after correcting: aria-invalid=' + fixed);
  // valid state
  await page.fill('#full-name', 'Dennis Sampa');
  await page.fill('#phone', '0971234567');
  await page.selectOption('#course', 'BSc Computer Science');
  await page.check('#floor-first');
  await page.selectOption('#seat', 'F12');
  await page.check('#need-power');
  await page.selectOption('#duration', '2');
  await page.fill('#notes', 'Please keep a seat near a socket.');
  await page.check('#consent');
  await page.click('button[type=submit]');
  await page.waitForTimeout(300);
  results.push(await runAxe('After successful submit'));
  await page.screenshot({ path: OUT + 'shot_valid.png', fullPage: true });
  // mobile reflow
  const m = await browser.newContext({ viewport: { width: 375, height: 800 } });
  const mp = await m.newPage(); await mp.goto(URL);
  await mp.evaluate(axeSrc);
  const mr = await mp.evaluate(async (tags) => await axe.run(document, { runOnly: { type: 'tag', values: tags } }), tags);
  results.push({ label: 'Mobile 375 px width', violations: mr.violations.map(v=>({id:v.id,impact:v.impact,help:v.help,nodes:v.nodes.length})), passes: mr.passes.length, incomplete: mr.incomplete.map(v=>({id:v.id,nodes:v.nodes.length})), inapplicable: mr.inapplicable.length });
  const sw = await mp.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  fs.writeFileSync(OUT + 'mobile_scrollwidth.txt', sw.join(' / '));
  await mp.screenshot({ path: OUT + 'shot_mobile.png', fullPage: false });
  // keyboard walkthrough on a fresh page
  const kp = await ctx.newPage(); await kp.goto(URL);
  const stops = [];
  for (let i = 1; i <= 40; i++) {
    await kp.keyboard.press('Tab');
    const info = await kp.evaluate(() => {
      const e = document.activeElement; if (!e || e === document.body) return null;
      const lab = e.id && document.querySelector('label[for="' + e.id + '"]');
      const cs = getComputedStyle(e);
      return { tag: e.tagName.toLowerCase(), type: e.getAttribute('type'), id: e.id, name: (lab ? lab.textContent : e.textContent || e.getAttribute('aria-label') || '').trim().replace(/\s+/g,' ').slice(0,50), outlineStyle: cs.outlineStyle, outlineWidth: cs.outlineWidth, outlineColor: cs.outlineColor, boxShadow: cs.boxShadow.slice(0,50) };
    });
    if (!info) break;
    stops.push(info);
    if (info.tag === 'button' && info.id === 'reset-btn') {
       // last stop
    }
    const key = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25].includes(i);
    await kp.evaluate((n) => { let b = document.getElementById('__badge'); if (!b) { b = document.createElement('div'); b.id='__badge'; b.style.cssText='position:fixed;right:12px;bottom:12px;background:#000;color:#fff;font:700 15px Arial;padding:6px 12px;border:2px solid #ffd54a;border-radius:6px;z-index:99999'; document.body.appendChild(b);} b.textContent='Tab stop '+n; }, i);
    await kp.screenshot({ path: OUT + 'tab_' + String(i).padStart(2,'0') + '.png' });
    if (info.id === 'reset-btn') break;
  }
  fs.writeFileSync(OUT + 'tabstops.json', JSON.stringify(stops, null, 2));
  // Shift+Tab check
  await kp.keyboard.press('Shift+Tab');
  const back = await kp.evaluate(() => document.activeElement.id || document.activeElement.textContent.trim());
  fs.writeFileSync(OUT + 'shifttab.txt', 'Shift+Tab from Clear form -> ' + back);
  fs.writeFileSync(OUT + 'axe_results.json', JSON.stringify({ axeVersion, results }, null, 2));
  console.log(JSON.stringify({ axeVersion, results }, null, 1));
  console.log('tab stops:', stops.length);
  await browser.close();
})();
